//
//  HQXMppManager.h
//  HQXMPPChat
//
//  Created by DinPay on 16/5/17.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import <Foundation/Foundation.h>

@class XMPPManager;

@protocol HQXMPPManagerAlertDelegate <NSObject>

- (void) XMPPManagerShowAlert:(UIAlertController *)alertController;

@end

typedef void (^MYBlock)(NSString *message, NSError *error);

@interface HQXMPPManager : NSObject<XMPPStreamDelegate,XMPPRosterDelegate,XMPPRosterMemoryStorageDelegate,XMPPIncomingFileTransferDelegate, XMPPOutgoingFileTransferDelegate>

@property (strong, nonatomic) XMPPStream *xmppStream;     //!< Stream流

@property (strong, nonatomic) XMPPAutoPing *xmppAutoPing;
@property (strong, nonatomic) XMPPReconnect *xmppReconnect;   //!< 重连接

@property (strong, nonatomic) XMPPRoster *xmppRoster;         //!< 获取好友列表
@property (strong, nonatomic) XMPPRosterMemoryStorage *xmppRosterMemoryStorage;    //!< 存储好友

@property (strong, nonatomic) XMPPMessageArchiving *xmppMessageArchiving;      //!< 消息归档
@property (strong, nonatomic) XMPPMessageArchivingCoreDataStorage *xmppMessageArchivingCoreDataStorage; //!< 消息归档数据库

@property (strong, nonatomic) XMPPIncomingFileTransfer *xmppIncomingFileTransfer;   //!< 文件传输

@property (strong, nonatomic) XMPPOutgoingFileTransfer *xmppOutgoingFileTransfer;   //!< 文件传输

@property (strong, nonatomic) XMPPPresence *receivePresence; //!< 在线状态管理

@property (weak, nonatomic) id<HQXMPPManagerAlertDelegate> delegate;


+ (instancetype)shareManager;

- (void) loginWithUserName:(NSString *)userName password:(NSString *)password complitionHandeler:(void (^)(NSString *message, NSError *error))complitionBlock;

- (void) registerWithUserName:(NSString *)userName password:(NSString *)password complitionHandeler:(void (^)(NSString *message, NSError *error))complitionBlock;

- (void)logout;

- (void)addFriendeWithName:(NSString *)name;

- (void)deleteFriendeWithName:(NSString *)name;

@end
