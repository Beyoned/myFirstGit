//
//  HQXMppManager.m
//  HQXMPPChat
//
//  Created by DinPay on 16/5/17.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import "HQXMPPManager.h"

//枚举
typedef NS_ENUM(NSInteger, ConnectToServerPurpose) {
    ConnectToServerPurposeRegister,
    ConnectToServerPurposeLogin
};


static HQXMPPManager *_manager = nil;

@interface HQXMPPManager ()
{
    void (^complitionCallBack)(NSString *message, NSError *error);
    
}

@property (nonatomic, strong) NSString *password;
@property (nonatomic, assign) ConnectToServerPurpose connectToServerPurpose;

@end

@implementation HQXMPPManager

+ (instancetype)shareManager
{
    if (_manager == nil) {
        
        @synchronized(self) {
            
            if (_manager == nil) {
                
                _manager = [[HQXMPPManager alloc] init];
            }
        }
    }
    return _manager;
}

- (XMPPStream *)xmppStream
{
    if (_xmppStream == nil) {
        _xmppStream = [[XMPPStream alloc] init];
        
        //socket 连接的时候 要知道host port 然后connect
        [_xmppStream setHostName:kXMPP_HOST];
        [_xmppStream setHostPort:kXMPP_PORT];
        //为什么是addDelegate? 因为xmppFramework 大量使用了多播代理multicast-delegate ,代理一般是1对1的，但是这个多播代理是一对多得，而且可以在任意时候添加或者删除
        [_xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        //添加功能模块
        //1.autoPing 发送的时一个stream:ping 对方如果想表示自己是活跃的，应该返回一个pong
        _xmppAutoPing = [[XMPPAutoPing alloc] init];
        //所有的Module模块，都要激活active
        [_xmppAutoPing activate:_xmppStream];
        
        //autoPing由于它会定时发送ping,要求对方返回pong,因此这个时间我们需要设置
        [_xmppAutoPing setPingInterval:1000];
        //不仅仅是服务器来得响应;如果是普通的用户，一样会响应
        [_xmppAutoPing setRespondsToQueries:YES];
        //这个过程是C---->S  ;观察 S--->C(需要在服务器设置）
        
        //2.autoReconnect 自动重连，当我们被断开了，自动重新连接上去，并且将上一次的信息自动加上去
        _xmppReconnect = [[XMPPReconnect alloc] init];
        [_xmppReconnect activate:_xmppStream];
        [_xmppReconnect setAutoReconnect:YES];
        
        
        // 3.好友模块 支持我们管理、同步、申请、删除好友
        _xmppRosterMemoryStorage = [[XMPPRosterMemoryStorage alloc] init];
        _xmppRoster = [[XMPPRoster alloc] initWithRosterStorage:_xmppRosterMemoryStorage];
        [_xmppRoster activate:_xmppStream];
        
        //同时给_xmppRosterMemoryStorage 和 _xmppRoster都添加了代理
        [_xmppRoster addDelegate:self delegateQueue:dispatch_get_main_queue()];
        //设置好友同步策略,XMPP一旦连接成功，同步好友到本地
        [_xmppRoster setAutoFetchRoster:YES]; //自动同步，从服务器取出好友
        //关掉自动接收好友请求，默认开启自动同意
        [_xmppRoster setAutoAcceptKnownPresenceSubscriptionRequests:NO];
        
        //4.消息模块，这里用单例，不能切换账号登录，否则会出现数据问题。
        _xmppMessageArchivingCoreDataStorage = [XMPPMessageArchivingCoreDataStorage sharedInstance];
        _xmppMessageArchiving = [[XMPPMessageArchiving alloc] initWithMessageArchivingStorage:_xmppMessageArchivingCoreDataStorage dispatchQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 9)];
        [_xmppMessageArchiving activate:_xmppStream];
        
        //5、文件接收
        _xmppIncomingFileTransfer = [[XMPPIncomingFileTransfer alloc] initWithDispatchQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)];
        [_xmppIncomingFileTransfer activate:_xmppStream];
        [_xmppIncomingFileTransfer addDelegate:self delegateQueue:dispatch_get_main_queue()];
        [_xmppIncomingFileTransfer setAutoAcceptFileTransfers:YES];
        
        _xmppOutgoingFileTransfer = [[XMPPOutgoingFileTransfer alloc] initWithDispatchQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)];
        [_xmppOutgoingFileTransfer activate:_xmppStream];
        [_xmppOutgoingFileTransfer addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
    }
    return _xmppStream;
}

//登录方法
- (void)loginWithUserName:(NSString *)userName password:(NSString *)password complitionHandeler:(void (^)(NSString *, NSError *))complitionBlock
{
    complitionCallBack = complitionBlock;
    
    self.connectToServerPurpose = ConnectToServerPurposeLogin;
    self.password = password;
    //连接服务器
    [self connectToServerWIthUserName:userName];
    
}

//注册方法
- (void)registerWithUserName:(NSString *)userName password:(NSString *)password complitionHandeler:(void (^)(NSString *, NSError *))complitionBlock
{
    complitionCallBack = complitionBlock;
    self.connectToServerPurpose = ConnectToServerPurposeRegister;
    self.password = password;
    //连接服务器
    [self connectToServerWIthUserName:userName];
}

//添加好友
- (void)addFriendeWithName:(NSString *)name
{
    //这里的nickname是我对它的备注，并非他得个人资料中得nickname
    XMPPJID *jid = [XMPPJID jidWithUser:name domain:kDomin resource:kResource];
    [self.xmppRoster addUser:jid withNickname:@"好友"];
    //加入好友到组
//    self.xmppRoster addUser:(XMPPJID *) withNickname:(NSString *) groups:(NSArray *)
//    self.xmppRoster addUser:(XMPPJID *) withNickname:(NSString *) groups:(NSArray *) subscribeToPresence:(BOOL)
}

//移除好友
- (void)deleteFriendeWithName:(NSString *)name
{
    XMPPJID *jid = [XMPPJID jidWithUser:name domain:kDomin resource:kResource];
    [self.xmppRoster removeUser:jid];
}

//连接服务器
- (void)connectToServerWIthUserName:(NSString *)userName {
    //创建XMPPJID对象,设置通信通道对象的JID
    XMPPJID *jid = [XMPPJID jidWithUser:userName domain:kDomin resource:kResource];
    self.xmppStream.myJID = jid;
    //发送请求
    if ([self.xmppStream isConnected] || [self.xmppStream isConnecting]) {
        //先发送下线状态
        XMPPPresence *presence = [XMPPPresence presenceWithType:@"unavailable"];
        [self.xmppStream sendElement:presence];
        //断开连接
        [self.xmppStream disconnect];
    }
    //向服务器发送请求
    NSError *error = nil;
    [self.xmppStream connectWithTimeout:-1 error:&error];
    if (error) {
        NSLog(@"%s__%d__%@| 连接失败", __FUNCTION__, __LINE__, [error localizedDescription]);
    }
}

#pragma mark ===== XMPPStream delegate =======
//socket 连接建立成功
- (void)xmppStream:(XMPPStream *)sender socketDidConnect:(GCDAsyncSocket *)socket
{
    NSLog(@"%s",__func__);
}

//xmpp连接成功
- (void)xmppStreamDidConnect:(XMPPStream *)sender {
    //连接成功后验证密码
    if (ConnectToServerPurposeLogin == self.connectToServerPurpose) {
        [self.xmppStream authenticateWithPassword:self.password error:nil];
    } else {
        BOOL result = [self.xmppStream registerWithPassword:self.password error:nil];
        NSNumber *number = [NSNumber numberWithBool:result];
        [[NSNotificationCenter defaultCenter] postNotificationName:kREGIST_RESULT object:number];
    }
}

//xmpp连接超时方法
- (void)xmppStreamConnectDidTimeout:(XMPPStream *)sender {
    NSLog(@"%s__%d__|连接超时", __FUNCTION__, __LINE__);
}

//xmpp连接出错
- (void)xmppStreamDidDisconnect:(XMPPStream *)sender withError:(NSError *)error
{
    NSLog(@"%s",__func__);
}

//注册成功
-(void)xmppStreamDidRegister:(XMPPStream *)sender
{
    NSLog(@"%s",__func__);
    
    NSError *result = nil;
    if (complitionCallBack) {
        
        complitionCallBack(nil, result);
    }
}

//注册失败
- (void)xmppStream:(XMPPStream *)sender didNotRegister:(DDXMLElement *)error
{
    NSLog(@"%s",__func__);
    
    NSError *result = nil;
    
    if (complitionCallBack) {
        
        complitionCallBack(@"注册失败", result);
    }
}


//登录失败
- (void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(DDXMLElement *)error
{
    NSLog(@"%s",__func__);

    NSError *result = nil;
    if (complitionCallBack) {
        
        complitionCallBack(@"登录失败", result);
    }
}

//登录成功
- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender
{
    [self goOnline];
    
    NSError *result = nil;
    if (complitionCallBack) {
        
        complitionCallBack(nil, result);
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:kLOGIN_SUCCESS object:nil];
}


#pragma mark ===== 好友模块 委托=======
/** 收到出席订阅请求（代表对方想添加自己为好友) */
- (void)xmppRoster:(XMPPRoster *)sender didReceivePresenceSubscriptionRequest:(XMPPPresence *)presence {
    
    NSString *message = [NSString stringWithFormat:@"【%@】想加你为好友",presence.from.bare];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"好友请求" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *accept = [UIAlertAction actionWithTitle:@"同意" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self.xmppRoster acceptPresenceSubscriptionRequestFrom:presence.from andAddToRoster:YES];
    }];
    
    UIAlertAction *reject = [UIAlertAction actionWithTitle:@"拒绝" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self.xmppRoster rejectPresenceSubscriptionRequestFrom:presence.from];
    }];
    
    [alert addAction:accept];
    [alert addAction:reject];
    
    if ([self.delegate respondsToSelector:@selector(XMPPManagerShowAlert:)]) {
        
        [self.delegate XMPPManagerShowAlert:alert];
    }
    
}

- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence
{
    //收到对方取消定阅我得消息
    if ([presence.type isEqualToString:@"unsubscribe"]) {
        //从我的本地通讯录中将他移除
        [self.xmppRoster removeUser:presence.from];
    }
}

- (void)goOnline
{
    // 发送一个<presence/> 默认值avaliable 在线 是指服务器收到空的presence 会认为是这个
    // status ---自定义的内容，可以是任何的。
    // show 是固定的，有几种类型 dnd(勿扰)、xa(离开一段时间)、away(离开)、chat(在线)，在方法XMPPPresence 的intShow中可以看到
    XMPPPresence *presence = [XMPPPresence presence];
    [presence addChild:[DDXMLNode elementWithName:@"status" stringValue:@"我现在很忙"]];
    [presence addChild:[DDXMLNode elementWithName:@"show" stringValue:@"chat"]];
    
    [self.xmppStream sendElement:presence];
}

- (void)logout
{
    //先发送下线状态
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"unavailable"];
    [self.xmppStream sendElement:presence];
    //断开连接
    [self.xmppStream disconnect];
}

/**
 * 开始同步服务器发送过来的自己的好友列表
 **/
- (void)xmppRosterDidBeginPopulating:(XMPPRoster *)sender
{
//    [[NSNotificationCenter defaultCenter] postNotificationName:kXMPP_ROSTER_CHANGE object:nil];
}

/**
 * 同步结束
 **/
//收到好友列表IQ会进入的方法，并且已经存入我的存储器
- (void)xmppRosterDidEndPopulating:(XMPPRoster *)sender
{
    [[NSNotificationCenter defaultCenter] postNotificationName:kXMPP_ROSTER_CHANGE object:nil];
}

//收到每一个好友
- (void)xmppRoster:(XMPPRoster *)sender didReceiveRosterItem:(NSXMLElement *)item
{
//    [[NSNotificationCenter defaultCenter] postNotificationName:kXMPP_ROSTER_CHANGE object:nil];
}


// 如果不是初始化同步来的roster,那么会自动存入我的好友存储器
- (void)xmppRosterDidChange:(XMPPRosterMemoryStorage *)sender
{
    [[NSNotificationCenter defaultCenter] postNotificationName:kXMPP_ROSTER_CHANGE object:nil];
}

#pragma mark - 文件发送代理
- (void)xmppOutgoingFileTransfer:(XMPPOutgoingFileTransfer *)sender
                didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError:%@",error);
}

- (void)xmppOutgoingFileTransferDidSucceed:(XMPPOutgoingFileTransfer *)sender
{
    NSLog(@"xmppOutgoingFileTransferDidSucceed");
    
    XMPPJID *jid = [sender.recipientJID copy];
    
    XMPPMessage *message = [XMPPMessage messageWithType:@"chat" to:jid];
    
    //将这个文件的发送者添加到message的from
    [message addAttributeWithName:@"from" stringValue:[HQXMPPManager shareManager].xmppStream.myJID.bare];
    [message addSubject:@"audio"];
    
    NSString *path =  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    path = [path stringByAppendingPathComponent:sender.outgoingFileName];
    
    [message addBody:path.lastPathComponent];
    
    [[HQXMPPManager shareManager].xmppMessageArchivingCoreDataStorage archiveMessage:message outgoing:NO xmppStream:[HQXMPPManager shareManager].xmppStream];
}


#pragma mark ===== 文件接收=======
/** 是否同意对方发文件给我 */
- (void)xmppIncomingFileTransfer:(XMPPIncomingFileTransfer *)sender didReceiveSIOffer:(XMPPIQ *)offer
{
    NSLog(@"%s",__FUNCTION__);
    //弹出一个是否接收的询问框
    [self.xmppIncomingFileTransfer acceptSIOffer:offer];
}
//文件传输成功
- (void)xmppIncomingFileTransfer:(XMPPIncomingFileTransfer *)sender didSucceedWithData:(NSData *)data named:(NSString *)name
{
    XMPPJID *jid = [sender.senderJID copy];
    NSLog(@"%s",__FUNCTION__);
    //在这个方法里面，我们通过带外来传输的文件
    //因此我们的消息同步器，不会帮我们自动生成Message,因此我们需要手动存储message
    //根据文件后缀名，判断文件我们是否能够处理，如果不能处理则直接显示。
    //图片 音频 （.wav,.mp3,.mp4)
    NSString *extension = [name pathExtension];
    if (![@"wav" isEqualToString:extension]) {
        return;
    }
    //创建一个XMPPMessage对象,message必须要有from
    XMPPMessage *message = [XMPPMessage messageWithType:@"chat" to:jid];
    //将这个文件的发送者添加到Message的from
    [message addAttributeWithName:@"from" stringValue:sender.senderJID.bare];
    [message addSubject:@"audio"];
    
    //保存data
    NSString *path =  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    path = [path stringByAppendingPathComponent:[XMPPStream generateUUID]];
    path = [path stringByAppendingPathExtension:@"wav"];
    [data writeToFile:path atomically:YES];
    
    [message addBody:path.lastPathComponent];
    
    [self.xmppMessageArchivingCoreDataStorage archiveMessage:message outgoing:NO xmppStream:self.xmppStream];
}

- (void)xmppOutgoingFileTransferIBBClosed:(XMPPOutgoingFileTransfer *)sender
{
    
}

#pragma mark - Message
//成功接收消息
- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message
{
    NSLog(@"%s--%@",__FUNCTION__, message);
    //XEP--0136 已经用coreData实现了数据的接收和保存
    
}

@end
