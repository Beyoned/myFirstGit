//
//  HQCantactsController.m
//  HQXMPPChat
//
//  Created by DinPay on 16/5/17.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import "HQCantactsController.h"
#import "HQChatController.h"
#import "HQContactCell.h"

#import "HQXMPPManager.h"

@interface HQCantactsController ()<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, retain) NSMutableArray *contacts;
@property (strong, nonatomic) UITextField *friendNameTF;

@end

@implementation HQCantactsController

#pragma mark -
#pragma mark - 懒加载
- (NSMutableArray *)contacts
{
    if (_contacts == nil) {
        _contacts = [NSMutableArray arrayWithArray:[HQXMPPManager shareManager].xmppRosterMemoryStorage.unsortedUsers];
    }
    return _contacts;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = [NSString stringWithFormat:@"%@的好友",[HQXMPPManager shareManager].xmppStream.myJID.user];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"HQContactCell" bundle:nil] forCellReuseIdentifier:@"contactCell"];
    self.tableView.rowHeight = 70;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rosterChange) name:kXMPP_ROSTER_CHANGE object:nil];
    
    UIBarButtonItem *addFriend = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addFriende:)];
    
    self.navigationItem.rightBarButtonItem = addFriend;
}

- (void)addFriende:(UIBarButtonItem *)item
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"添加好友" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *addFriend = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[HQXMPPManager shareManager] addFriendeWithName:self.friendNameTF.text];
    }];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        self.friendNameTF = textField;
    }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alert addAction:addFriend];
    [alert addAction:cancel];
    
    [self presentViewController:alert animated:YES completion:nil];

}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kXMPP_ROSTER_CHANGE object:nil];
}

#pragma mark - notification event
- (void)rosterChange
{
    //从存储器中取出我得好友数组，更新数据源
    self.contacts = [NSMutableArray arrayWithArray:[HQXMPPManager shareManager].xmppRosterMemoryStorage.unsortedUsers];
    [self.tableView reloadData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.contacts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    HQContactCell *cell = [tableView dequeueReusableCellWithIdentifier:@"contactCell"];
    
    XMPPUserMemoryStorageObject *user = self.contacts[indexPath.row];
    
    cell.iconName = @"wechat";
    
    cell.name = user.jid.user;
    
    if ([user isOnline]) {
        cell.status = @"[在线]";
    } else {
        cell.status = @"[离线]";
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    HQChatController *chatVC = [[HQChatController alloc] init];
    
    XMPPUserMemoryStorageObject *user = self.contacts[indexPath.row];
    
    chatVC.friendJID = user.jid;
    
    [self.navigationController pushViewController:chatVC animated:YES];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        XMPPUserMemoryStorageObject *user = self.contacts[indexPath.row];
        
        [[HQXMPPManager shareManager] deleteFriendeWithName:user.jid.user];
        
        [self.contacts removeObjectAtIndex:indexPath.row];
        
        [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
    }
}

//- (UITableViewCellEditingStyle) tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
