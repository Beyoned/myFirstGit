//
//  HQChatCell.h
//  HQXMPPChat
//
//  Created by DinPay on 16/5/18.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HQContactCell : UITableViewCell

@property (copy, nonatomic)NSString *iconName;

@property (copy, nonatomic)NSString *status;

@property (copy, nonatomic)NSString *name;

@end
