//
//  HQChatCell.m
//  HQXMPPChat
//
//  Created by DinPay on 16/5/18.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import "HQContactCell.h"

@interface HQContactCell ()
@property (weak, nonatomic) IBOutlet UILabel *nameLB;
@property (weak, nonatomic) IBOutlet UIImageView *iconIV;
@property (weak, nonatomic) IBOutlet UILabel *statusLB;

@end


@implementation HQContactCell

- (void)setName:(NSString *)name
{
    _name = name;
    self.nameLB.text = name;
}

- (void)setIconName:(NSString *)iconName
{
    _iconName = iconName;
    self.iconIV.image = [UIImage imageNamed:iconName];
}

- (void)setStatus:(NSString *)status
{
    _status = status;
    self.statusLB.text = status;
}

- (void)awakeFromNib {
    // Initialization code
    
    self.iconIV.layer.cornerRadius = 25;
    self.iconIV.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
