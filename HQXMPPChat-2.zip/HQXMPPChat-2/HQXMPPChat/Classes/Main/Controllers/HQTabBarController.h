//
//  HQTabBarController.h
//  HQXMPPChat
//
//  Created by DinPay on 16/5/17.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HQTabBarController : UITabBarController

@end
