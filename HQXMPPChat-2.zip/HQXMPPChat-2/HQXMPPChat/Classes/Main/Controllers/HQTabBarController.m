//
//  HQTabBarController.m
//  HQXMPPChat
//
//  Created by DinPay on 16/5/17.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import "HQTabBarController.h"
#import "HQNavigationController.h"
#import "HQCantactsController.h"
#import "HQRoomController.h"
#import "HQSettingController.h"
#import "HQXMPPManager.h"

@interface HQTabBarController ()<HQXMPPManagerAlertDelegate>

@end

@implementation HQTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [HQXMPPManager shareManager].delegate = self;
    
    UITabBar *hqBar = [UITabBar appearance];
    
    [hqBar setBackgroundColor:[UIColor blackColor]];
    
    HQCantactsController *cantactsVC = [[HQCantactsController alloc] init];
    [self addChildViewController:cantactsVC title:@"联系人" image:@"ic_nav_4_normal" selectedImage:@"ic_nav_4_active"];
    HQRoomController *roomVC = [[HQRoomController alloc] init];
    [self addChildViewController:roomVC title:@"聊天室" image:@"ic_nav_3_normal" selectedImage:@"ic_nav_3_active"];
    HQSettingController *settingVC = [[HQSettingController alloc] init];
    [self addChildViewController:settingVC title:@"设置" image:@"ic_nav_5_normal" selectedImage:@"ic_nav_5_active"];
    
}

- (void)addChildViewController:(UIViewController *)childController title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    HQNavigationController *nVC = [[HQNavigationController alloc] initWithRootViewController:childController];
    
    nVC.tabBarItem.title = title;
    
    nVC.tabBarItem.image = [[UIImage imageNamed:image] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nVC.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    [self addChildViewController:nVC];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)XMPPManagerShowAlert:(UIAlertController *)alertController
{
    [self presentViewController:alertController animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
