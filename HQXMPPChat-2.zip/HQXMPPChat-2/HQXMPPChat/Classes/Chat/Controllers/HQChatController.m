//
//  HQChatController.m
//  HQXMPPChat
//
//  Created by DinPay on 16/5/17.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import "HQChatController.h"
#import "HQChatCell.h"
#import "HQChatCellF.h"
#import "HQAudioCell.h"
#import "HQAudioCellF.h"

#import "HQXMPPManager.h"

#import <AVFoundation/AVFoundation.h>

@interface HQChatController ()<UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITextField *chatTF;
@property (weak, nonatomic) IBOutlet UIView *bottomView;

@property (strong, nonatomic) NSMutableArray *chatContents;

@property (nonatomic, retain) AVAudioRecorder   *recorder;
@property (nonatomic, retain) AVAudioPlayer     *player;

@property (nonatomic, strong) XMPPOutgoingFileTransfer *xmppOutgoingFileTransfer;

@end

@implementation HQChatController

- (NSMutableArray *)chatContents
{
    if (_chatContents == nil) {
        _chatContents = [NSMutableArray array];
    }
    return _chatContents;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.navigationItem.title = [NSString stringWithFormat:@"与%@正在聊天",self.friendJID.user];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"HQChatCell" bundle:nil] forCellReuseIdentifier:@"HQChatCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"HQChatCellF" bundle:nil] forCellReuseIdentifier:@"HQChatCellF"];
    [self.tableView registerNib:[UINib nibWithNibName:@"HQAudioCell" bundle:nil] forCellReuseIdentifier:@"HQAudioCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"HQAudioCellF" bundle:nil] forCellReuseIdentifier:@"HQAudioCellF"];
    
    self.tableView.estimatedRowHeight = 100;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyBoard)];
    [self.tableView addGestureRecognizer:tapGesture];
    
    [self getChatHistory];
    
    [self addNotifications];
    
    self.chatTF.delegate = self;

}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kXMPP_MESSAGE_CHANGE object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [_xmppOutgoingFileTransfer removeDelegate:self];
    [_xmppOutgoingFileTransfer deactivate];
    _xmppOutgoingFileTransfer = nil;
}

- (void)addNotifications
{
    //通知在XMPPMessageArchivingCoreDataStorage保存好信息后创建 archiveMessage: outgoing: xmppStream:
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getChatHistory) name:kXMPP_MESSAGE_CHANGE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillSHow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - private method
/** 发送的事件 */
- (void)sendMessage{
    if (self.chatTF.text.length < 1) {
        return;
    }
    XMPPMessage *message = [XMPPMessage messageWithType:@"chat" to:self.friendJID];
    [message addBody:self.chatTF.text];
    [[HQXMPPManager shareManager].xmppStream sendElement:message];
    
    self.chatTF.text = @"";
    
    [self tableViewScrollToBottom];
}


- (void)tableViewScrollToBottom
{
    if (self.chatContents.count > 0) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:(self.chatContents.count-1) inSection:0];
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
}

/** 查询聊天记录 */
- (void)getChatHistory
{
    XMPPMessageArchivingCoreDataStorage *storage = [HQXMPPManager shareManager].xmppMessageArchivingCoreDataStorage;
    //查询的时候要给上下文
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:storage.messageEntityName inManagedObjectContext:storage.mainThreadManagedObjectContext];
    [fetchRequest setEntity:entity];
    // Specify criteria for filtering which objects to fetch
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"bareJidStr == %@ and streamBareJidStr == %@", self.friendJID.bare, [HQXMPPManager shareManager].xmppStream.myJID.bare];
    [fetchRequest setPredicate:predicate];
    // Specify how the fetched objects should be sorted
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"timestamp"
                                                                   ascending:YES];
    [fetchRequest setSortDescriptors:[NSArray arrayWithObjects:sortDescriptor, nil]];
    
    NSError *error = nil;
    NSArray *fetchedObjects = [storage.mainThreadManagedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects != nil) {
        self.chatContents = [[NSMutableArray alloc] initWithArray:fetchedObjects];
        //        [NSMutableArray arrayWithArray:fetchedObjects];
    }
    
    [self.tableView reloadData];
    
    [self tableViewScrollToBottom];
}

- (IBAction)startRecord:(UIButton *)sender {
    NSString *path =  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    path = [path stringByAppendingPathComponent:[XMPPStream generateUUID]];
    path = [path stringByAppendingPathExtension:@"wav"];
    
    NSURL *URL = [NSURL fileURLWithPath:path];
    _recorder = [[AVAudioRecorder alloc] initWithURL:URL settings:nil error:nil];
    [_recorder prepareToRecord];
    [_recorder record];

}

- (IBAction)sendRecord:(UIButton *)sender {
    [_recorder stop];
    NSArray *resources = [HQXMPPManager shareManager].xmppRosterMemoryStorage.unsortedUsers;
    for (XMPPResourceMemoryStorageObject *object in resources) {
        if ([object.jid.bare isEqualToString:self.friendJID.bare]) {
            NSData *data = [[[NSData alloc] initWithContentsOfURL:_recorder.url] copy];
            NSError *err;
            [self.xmppOutgoingFileTransfer sendData:data named:_recorder.url.lastPathComponent toRecipient:object.jid description:nil error:&err];
            if (err) {
                NSLog(@"%@",err);
            }
            break;
        }
    }
    
    _recorder = nil;
}

- (IBAction)cancelRecord:(UIButton *)sender {
    [_recorder stop];
    [[NSFileManager defaultManager] removeItemAtURL:_recorder.url error:nil];
    _recorder = nil;

}

- (IBAction)selecteEmoji:(UIButton *)sender {
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - notification event
- (void)hideKeyBoard
{
    [self.view endEditing:YES];
}

- (void)keyboardWillSHow:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    CGSize size = [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    NSNumber *duration = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    
    [UIView animateWithDuration:duration.doubleValue animations:^{
        self.bottomView.transform = CGAffineTransformMakeTranslation(0, -size.height);
        CGRect rect = self.tableView.frame;
        rect.size.height = kScreenHeight-50-size.height;
        self.tableView.frame = rect;
        [self tableViewScrollToBottom];
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    NSNumber *duration = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    
    [UIView animateWithDuration:duration.doubleValue animations:^{
        self.bottomView.transform = CGAffineTransformIdentity;
        CGRect rect = self.tableView.frame;
        rect.size.height = kScreenHeight-50;
        self.tableView.frame = rect;
    }];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self sendMessage];
    return YES;
}


#pragma mark - 
#pragma mark -UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.chatContents.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //先判断这个消息显示在哪边
    XMPPMessageArchiving_Message_CoreDataObject *message = self.chatContents[indexPath.row];
    if (message.isOutgoing) {
        
        if ([message.message.subject isEqualToString:@"audio"]) {
            
            HQAudioCellF *cell = [tableView dequeueReusableCellWithIdentifier:@"HQAudioCellF"];
//            cell.playVoiceBlock =
            
            return cell;
        }else {
            
            HQChatCellF *cell = [tableView dequeueReusableCellWithIdentifier:@"HQChatCellF"];
            
            cell.message = message.body;
            cell.time = [self dateTransformToLocalDate:message.timestamp];
            
            return cell;
        }
    }else {
        if ([message.message.subject isEqualToString:@"audio"]) {
            
            HQAudioCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HQAudioCell"];
//            cell.playVoiceBlock =
            
            return cell;
            
        }else {
            
            HQChatCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HQChatCell"];
            
            cell.message = message.body;
            cell.time = [self dateTransformToLocalDate:message.timestamp];
            return cell;
        }
    }
}

//将标准失去时间转化为当地时间
- (NSString *)dateTransformToLocalDate:(NSDate *)date
{
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc]init];
    
    [dateFormatter setDateStyle:NSDateFormatterFullStyle];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    return [dateFormatter stringFromDate:date];
}

- (void)playVoice:(UIButton *)btn
{
    XMPPMessageArchiving_Message_CoreDataObject *message = self.chatContents[btn.tag];
    NSString *path =  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    path = [path stringByAppendingPathComponent:message.body];
    NSURL *url = [NSURL URLWithString:path];
    
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
    [self.player prepareToPlay];
    [self.player play];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.tabBarController.tabBar.hidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.tabBarController.tabBar.hidden = NO;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
