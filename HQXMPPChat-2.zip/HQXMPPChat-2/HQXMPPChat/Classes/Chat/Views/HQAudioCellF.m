//
//  HQAudioCellF.m
//  HQXMPPChat
//
//  Created by DinPay on 16/5/18.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import "HQAudioCellF.h"

@interface HQAudioCellF ()

@property (weak, nonatomic) IBOutlet UILabel *timeLB;
@property (weak, nonatomic) IBOutlet UIImageView *iconIV;
@property (weak, nonatomic) IBOutlet UIButton *audioBtn;

@end

@implementation HQAudioCellF

- (void)setTime:(NSString *)time
{
    _time = time;
    self.timeLB.text = time;
}

- (void)awakeFromNib {
    // Initialization code
    self.iconIV.layer.cornerRadius = 25;
    self.iconIV.clipsToBounds = YES;
    self.backgroundColor = [UIColor clearColor];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
