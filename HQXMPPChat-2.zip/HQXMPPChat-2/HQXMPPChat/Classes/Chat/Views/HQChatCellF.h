//
//  HQChatCell.h
//  HQXMPPChat
//
//  Created by DinPay on 16/5/18.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HQChatCellF : UITableViewCell

@property (copy, nonatomic) NSString *message;

@property (copy, nonatomic) NSString *time;

@end
