//
//  HQAudioCellF.h
//  HQXMPPChat
//
//  Created by DinPay on 16/5/18.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HQAudioCellF : UITableViewCell

@property (copy, nonatomic) NSString *time;

@end
