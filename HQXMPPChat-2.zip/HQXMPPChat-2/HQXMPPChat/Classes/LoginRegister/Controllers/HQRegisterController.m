//
//  HQRegisterController.m
//  HQXMPPChat
//
//  Created by DinPay on 16/5/18.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import "HQRegisterController.h"
#import "HQXMPPManager.h"

@interface HQRegisterController ()

//@property (strong, nonatomic) UILabel *accountLB;
//@property (strong, nonatomic) UILabel *passwordLB;
//
//@property (strong, nonatomic) UITextField *accountTF;
//@property (strong, nonatomic) UITextField *passwordTF;
//
//@property (strong, nonatomic) UIButton *registerBtn;

@property (weak, nonatomic) IBOutlet UITextField *accountTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;
@property (weak, nonatomic) IBOutlet UIButton *registerBtn;
@property (weak, nonatomic) IBOutlet UITextField *confirmTF;

@end

@implementation HQRegisterController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(registerResult:) name:kREGIST_RESULT object:nil];
}

- (IBAction)clickedRegisterBtn:(UIButton *)sender {
    
    NSString *account = self.accountTF.text;
    NSString *password = self.passwordTF.text;
    NSString *confirmPwd = self.confirmTF.text;
    
    NSString *message = nil;
    
    if (![confirmPwd isEqualToString:password]) {
        message = @"密码不一致，请重新设置";
    }else if (account.length <= 0) {
        message = @"用户名未填写";
    } else if (password.length <= 0) {
        message = @"密码未填写";
    } else if (confirmPwd.length <= 0) {
        message = @"确认密码未填写";
    }

    if (message.length > 0) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示：" message:message preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *sure = [UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:nil];
        
        [alert addAction:sure];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        [[HQXMPPManager shareManager] registerWithUserName:account password:confirmPwd complitionHandeler:^(NSString *message, NSError *error) {
            if (message == nil) {
                
                [self.navigationController popViewControllerAnimated:YES];
            }else {
                
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示：" message:message preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction *sure = [UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:nil];
                
                [alert addAction:sure];
                
                [self presentViewController:alert animated:YES completion:nil];
            }
        }];
    }
}


//-(void) registerResult:(NSNotification *)notification
//{
//    NSNumber *number = notification.object;
//    NSString *message = @"";
//    if (number.boolValue) {
//        message = @"注册成功";
//    } else {
//        message = @"注册失败";
//    }
//    
//    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示：" message:message preferredStyle:UIAlertControllerStyleAlert];
//    
//    UIAlertAction *sure = [UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:nil];
//    
//    [alert addAction:sure];
//    
//    [self presentViewController:alert animated:YES completion:nil];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
