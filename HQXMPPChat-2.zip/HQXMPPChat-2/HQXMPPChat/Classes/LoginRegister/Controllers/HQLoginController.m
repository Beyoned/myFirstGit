//
//  HQLoginController.m
//  HQXMPPChat
//
//  Created by DinPay on 16/5/17.
//  Copyright © 2016年 Ape. All rights reserved.
//

#import "HQLoginController.h"
#import "HQTabBarController.h"
#import "HQRegisterController.h"

#import "HQXMPPManager.h"
#import "AppDelegate.h"

@interface HQLoginController ()
@property (weak, nonatomic) IBOutlet UITextField *accountTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;

@end

@implementation HQLoginController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = YES;
}

- (IBAction)clickedLoginBtn:(UIButton *)sender {
    
    NSString *account = self.accountTF.text;
    NSString *password = self.passwordTF.text;
    
    NSString *message = nil;
    
    if (account.length <= 0) {
        message = @"用户名未填写";
    } else if (password.length <= 0) {
        message = @"密码未填写";
    }
    if (message.length > 0) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示：" message:message preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *sure = [UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:nil];
        
        [alert addAction:sure];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        [[HQXMPPManager shareManager] loginWithUserName:account password:password complitionHandeler:^(NSString *message, NSError *error) {
            if (message == nil) {
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    
                    HQTabBarController *hqTabBar = [[HQTabBarController alloc] init];
                    
                    AppDelegate *delegate = [UIApplication sharedApplication].delegate;
                    
                    delegate.window.rootViewController = hqTabBar;
                });
                
            }else {
                
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示：" message:message preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction *sure = [UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:nil];
                
                [alert addAction:sure];
                
                [self presentViewController:alert animated:YES completion:nil];
            }
        }];
    }
}

- (IBAction)clickedRegisterBtn:(UIButton *)sender {
    
    HQRegisterController *registerVC = [[HQRegisterController alloc] init];
    
    [self.navigationController pushViewController:registerVC animated:YES];
}

- (IBAction)clickedForgetBtn:(UIButton *)sender {
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    self.navigationController.navigationBarHidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
